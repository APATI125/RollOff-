﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace RollOffBackend
{
    public partial class RollOffContext : DbContext
    {
        public RollOffContext()
        {
        }

        public RollOffContext(DbContextOptions<RollOffContext> options)
            : base(options)
        {
        }

        public virtual DbSet<FormTable> FormTables { get; set; }
        public virtual DbSet<LoginTable> LoginTables { get; set; }
        public virtual DbSet<RollOffTable> RollOffTables { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("name=connectionString");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<FormTable>(entity =>
            {
                entity.HasKey(e => e.Guid)
                    .HasName("PK__FormTabl__15B69B8E393DEA6D");

                entity.ToTable("FormTable");

                entity.HasIndex(e => e.GlobalGroupId, "IX_FormTable_Global Group ID");

                entity.Property(e => e.Guid)
                    .HasColumnName("GUID")
                    .HasDefaultValueSql("(newsequentialid())");

                entity.Property(e => e.Communication).HasMaxLength(255);

                entity.Property(e => e.EmployeeNumber).HasColumnName("Employee Number");

                entity.Property(e => e.GlobalGroupId).HasColumnName("Global Group ID");

                entity.Property(e => e.LabourWorkforceProductivitySpecified).HasColumnName("Labour(Workforce productivity) Specified");

                entity.Property(e => e.LeaveType)
                    .HasMaxLength(255)
                    .HasColumnName("Leave Type");

                entity.Property(e => e.LocalGrade)
                    .HasMaxLength(255)
                    .HasColumnName("Local Grade");

                entity.Property(e => e.LongLeave)
                    .HasMaxLength(255)
                    .HasColumnName("Long Leave");

                entity.Property(e => e.Name).HasMaxLength(255);

                entity.Property(e => e.OtherReason).HasColumnName("Other Reason");

                entity.Property(e => e.PerformanceIssue)
                    .HasMaxLength(255)
                    .HasColumnName("Performance Issue");

                entity.Property(e => e.Practice).HasMaxLength(255);

                entity.Property(e => e.PrimarySkill)
                    .HasMaxLength(255)
                    .HasColumnName("Primary Skill");

                entity.Property(e => e.ProjectCode).HasColumnName("Project Code");

                entity.Property(e => e.ProjectName)
                    .HasMaxLength(255)
                    .HasColumnName("Project Name");

                entity.Property(e => e.ReasonForRollOff)
                    .HasMaxLength(255)
                    .HasColumnName("Reason for Roll Off");

                entity.Property(e => e.RelevantExperienceYears).HasColumnName("Relevant Experience (Years)");

                entity.Property(e => e.Remarks).HasMaxLength(255);

                entity.Property(e => e.RequestDate)
                    .HasColumnType("date")
                    .HasColumnName("Request Date");

                entity.Property(e => e.Resigned).HasMaxLength(255);

                entity.Property(e => e.RoleCompetencies)
                    .HasMaxLength(255)
                    .HasColumnName("Role/Competencies");

                entity.Property(e => e.RollOffEndDate)
                    .HasColumnType("date")
                    .HasColumnName("Roll-Off End Date");

                entity.Property(e => e.Status).HasMaxLength(255);

                entity.Property(e => e.TechnicalSkills)
                    .HasMaxLength(255)
                    .HasColumnName("Technical Skills");

                entity.Property(e => e.ThisReleaseNeedsBackfillIsBackfilled)
                    .HasMaxLength(255)
                    .HasColumnName("This release needs backfill/is backfilled");

                entity.Property(e => e.UnderProbation)
                    .HasMaxLength(255)
                    .HasColumnName("Under Probation");

                entity.HasOne(d => d.GlobalGroup)
                    .WithMany(p => p.FormTables)
                    .HasForeignKey(d => d.GlobalGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FormTable_RollOffTable");
            });

            modelBuilder.Entity<LoginTable>(entity =>
            {
                entity.HasKey(e => e.Userid)
                    .HasName("PK__LoginTab__1797D02407C06B10");

                entity.ToTable("LoginTable");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Roles)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<RollOffTable>(entity =>
            {
                entity.HasKey(e => e.GlobalGroupId)
                    .HasName("PK__RollOffT__A8B3AC1A9CA960DB");

                entity.ToTable("RollOffTable");

                entity.Property(e => e.GlobalGroupId).HasColumnName("Global Group ID");

                entity.Property(e => e.Country).HasMaxLength(255);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.EmployeeNo).HasColumnName("Employee no");

                entity.Property(e => e.JoiningDate)
                    .HasColumnType("datetime")
                    .HasColumnName("Joining Date");

                entity.Property(e => e.LocalGrade)
                    .HasMaxLength(255)
                    .HasColumnName("Local Grade");

                entity.Property(e => e.MainClient)
                    .HasMaxLength(255)
                    .HasColumnName("Main Client");

                entity.Property(e => e.Name).HasMaxLength(255);

                entity.Property(e => e.NewGlobalPractice)
                    .HasMaxLength(255)
                    .HasColumnName("New Global Practice");

                entity.Property(e => e.OfficeCity)
                    .HasMaxLength(255)
                    .HasColumnName("Office City");

                entity.Property(e => e.PeopleManagerPerformanceReviewer)
                    .HasMaxLength(255)
                    .HasColumnName("People Manager (Performance Reviewer)");

                entity.Property(e => e.Practice).HasMaxLength(255);

                entity.Property(e => e.ProjectCode).HasColumnName("Project Code");

                entity.Property(e => e.ProjectEndDate)
                    .HasColumnType("datetime")
                    .HasColumnName("Project End Date");

                entity.Property(e => e.ProjectName)
                    .HasMaxLength(255)
                    .HasColumnName("Project Name");

                entity.Property(e => e.ProjectStartDate)
                    .HasColumnType("datetime")
                    .HasColumnName("Project Start Date");

                entity.Property(e => e.PspName)
                    .HasMaxLength(255)
                    .HasColumnName("PSP Name");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
