﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public class RollOffRepository:IRollOffRepository
    {
        #region DI
        private readonly RollOffContext roll_OffContext;
        public RollOffRepository(RollOffContext roll_OffContext)
        {
            this.roll_OffContext = roll_OffContext;
        }
        #endregion

        #region Get all supply information
        public async Task<IEnumerable<RollOffTable>> GetallDetailsAsync()
        {
            var employees = await roll_OffContext.RollOffTables.ToListAsync();
            return employees;
        }
        #endregion

        #region Get supply information from GGID
        public async Task<RollOffTable> GetbyGGIDAsync(double ggid)
        {
            var employee = await roll_OffContext.RollOffTables.FirstOrDefaultAsync(x => x.GlobalGroupId == ggid);
            return employee;
        }

        #endregion

        #region Get supply information by Email
        public async Task<RollOffTable> GetbyEmailAsync(string value)
        {
            return await roll_OffContext.RollOffTables.FirstOrDefaultAsync(x => x.Email == value);
        }
        #endregion
    }
}
