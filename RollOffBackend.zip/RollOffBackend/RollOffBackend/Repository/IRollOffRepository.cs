﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public interface IRollOffRepository
    {
        Task<IEnumerable<RollOffTable>> GetallDetailsAsync();
        Task<RollOffTable> GetbyGGIDAsync(double ggid);
        Task<RollOffTable> GetbyEmailAsync(string email);
    }
}
