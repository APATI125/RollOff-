﻿using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public interface IUserRepository
    {
        Task<LoginTable> AuthenticateUserAsync(string email, string password, string role);
    }
}
