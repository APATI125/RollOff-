﻿using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public interface ITokenHandler
    {
        Task<string> CreateTokenAsync(LoginTable loginTable);
    }
}
