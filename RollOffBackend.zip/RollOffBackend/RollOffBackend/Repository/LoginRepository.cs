﻿using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public class LoginRepository:ILoginRepository
    {
        #region DI
        private readonly RollOffContext context;

        public LoginRepository(RollOffContext context)
        {
            this.context = context;
        }
        #endregion

        #region Create new user
        public async Task<LoginTable> AddLoginDetailsAsync(LoginTable loginTable)
        {
            await context.LoginTables.AddAsync(loginTable);
            await context.SaveChangesAsync();
            return loginTable;
        }
        #endregion
    }
}
