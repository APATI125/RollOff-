﻿using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using MimeKit.Text;
using RollOffBackend.Models;

namespace RollOffBackend.Repository
{
    public class EmailRepository:IEmailRepository
    {
        #region Email
        public void SendEmail(Email request)
        {  
          var email = new MimeMessage();
          email.From.Add(MailboxAddress.Parse("donaldshr998@outlook.com"));
          email.To.Add(MailboxAddress.Parse(request.To));
          email.Subject = "New Email";
          email.Body = new TextPart(TextFormat.Html) { Text = request.Body };
            
          using var smtp = new SmtpClient();            
          smtp.Connect("smtp.office365.com", 587, SecureSocketOptions.StartTls);
          smtp.Authenticate("donaldshr998@outlook.com", "yaqdmxqckrpnnguo");            
          smtp.Send(email);            
          smtp.Disconnect(true);         }
        }
    #endregion
}
