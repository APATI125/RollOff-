﻿using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public class UserRepository:IUserRepository
    {
        #region DI
        private readonly RollOffContext context;
        public UserRepository(RollOffContext context)
        {
            this.context = context;
        }
        #endregion

        #region Authneticate User
        public async Task<LoginTable> AuthenticateUserAsync(string email, string password, string role)
        {
            var user = await context.LoginTables.FirstOrDefaultAsync(x => x.Email == email && x.Password == password && x.Roles == role);
            return user;
        }
        #endregion
    }
}
