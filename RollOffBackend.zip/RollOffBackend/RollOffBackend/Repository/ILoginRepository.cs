﻿using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public interface ILoginRepository
    {
        Task<LoginTable> AddLoginDetailsAsync(LoginTable loginTable);
    }
}
