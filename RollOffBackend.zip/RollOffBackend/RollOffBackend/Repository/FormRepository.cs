﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RollOffBackend.Repository
{
    public class FormRepository : IFormRepository
    {
        #region DI
        private readonly RollOffContext context;
        public FormRepository(RollOffContext context)
        {
            this.context = context;
        }
        #endregion

        #region Create New FeedbackForm
        public async Task<FormTable> AddFormAsync(FormTable form)
        {
            await context.FormTables.AddAsync(form);
            await context.SaveChangesAsync();
            return form;
        }
        #endregion

        #region Delete Form

        public async Task<FormTable> DeleteForm(double ggid)
        {
            var formDetails = await context.FormTables.FirstOrDefaultAsync(x => x.GlobalGroupId == ggid);
            context.FormTables.Remove(formDetails);
            await context.SaveChangesAsync();
            return formDetails;
        }
        #endregion

        #region Get all form Details

        public async Task<IEnumerable<FormTable>> GetDetailsAsync()
        {
            return await context.FormTables.ToListAsync();
        }
        #endregion

        #region Get Form details by ggid
        public async Task<FormTable> GetDetailsGGID(double ggid)
        {
            var formdetails = await context.FormTables.FirstOrDefaultAsync(x => x.GlobalGroupId == ggid);
            return formdetails;
        }
        #endregion

        #region Update form details

        public async Task<FormTable> UpdateForm(double ggid, FormTable form)
        {
            var existingemployee = await context.FormTables.FirstOrDefaultAsync(x => x.GlobalGroupId == ggid);
            if(existingemployee == null)
            {
                return null;
            }
            existingemployee.EmployeeNumber = form.EmployeeNumber;
            existingemployee.Name = form.Name;
            existingemployee.PrimarySkill = form.PrimarySkill;
            existingemployee.LocalGrade = form.LocalGrade;
            existingemployee.ProjectCode = form.ProjectCode;
            existingemployee.ProjectName = form.ProjectName;
            existingemployee.Practice = form.Practice;
            existingemployee.RollOffEndDate = form.RollOffEndDate;
            existingemployee.ReasonForRollOff = form.ReasonForRollOff;
            existingemployee.ThisReleaseNeedsBackfillIsBackfilled = form.ThisReleaseNeedsBackfillIsBackfilled;
            existingemployee.PerformanceIssue = form.PerformanceIssue;
            existingemployee.Resigned = form.Resigned;
            existingemployee.UnderProbation = form.UnderProbation;
            existingemployee.LongLeave = form.LongLeave;
            existingemployee.TechnicalSkills = form.TechnicalSkills;
            existingemployee.Communication = form.Communication;
            existingemployee.RoleCompetencies = form.RoleCompetencies;
            existingemployee.Remarks = form.Remarks;
            existingemployee.RelevantExperienceYears = form.RelevantExperienceYears;
            existingemployee.Status = form.Status;
            existingemployee.RequestDate = form.RequestDate;
            existingemployee.LabourWorkforceProductivitySpecified = form.LabourWorkforceProductivitySpecified;
            existingemployee.LeaveType = form.LeaveType;
            existingemployee.OtherReason = form.OtherReason;

            await context.SaveChangesAsync();
            return existingemployee;
        }
        #endregion
    }
}
