﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RollOffBackend.Models;
using RollOffBackend.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RollOffBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly IEmailRepository _emailRepository;


        public EmailController(IEmailRepository emailRepository) 
        { 
            _emailRepository = emailRepository; 
        }


        [HttpPost] 
        public IActionResult SendEmail(Email email) 
        { 
            _emailRepository.SendEmail(email); 
            return Ok(); 
        }
    }
}
