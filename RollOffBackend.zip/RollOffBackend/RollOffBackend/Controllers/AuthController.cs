﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RollOffBackend.DTO;
using RollOffBackend.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RollOffBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository userRepository;
        private readonly ITokenHandler handler;

        public AuthController(IUserRepository userRepository, ITokenHandler handler)
        {
            this.userRepository = userRepository;
            this.handler = handler;
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> LoginAsync(LoginRequestDTO loginRequestDTO)
        {
            if(loginRequestDTO.Email==null && loginRequestDTO.Password == null && loginRequestDTO.Roles==null)
            {
                return NotFound("email or password is null");
            }

            var user = await userRepository.AuthenticateUserAsync(loginRequestDTO.Email, loginRequestDTO.Password, loginRequestDTO.Roles);
            if (user != null)
            {
                var token = handler.CreateTokenAsync(user);
                return Ok(token);
            }
            return BadRequest("Username or password or Role is incorrect");
        }
    }
}
